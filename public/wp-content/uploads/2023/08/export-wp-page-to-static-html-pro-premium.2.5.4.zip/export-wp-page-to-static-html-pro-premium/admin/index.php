<?php // Silence is golden

$wpDir = str_replace('wp-content\plugins\export-wp-page-to-static-html-pro-master\admin', '', __DIR__);
require($wpDir.'wp-load.php');
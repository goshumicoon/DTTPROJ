<?php

    namespace ExportHtmlAdmin\Zip;
    /**
     * Class name: FtpFunctions
     */
    class Zip2 extends \ExportHtmlAdmin\Export_Wp_Page_To_Static_Html_Admin
    {
        public function __construct()
        {

        }


}
